Compilado e executado em ambiente Windows através do comando :

ocaml.exe efolio1.ml temperaturas.txt precipitacoes.txt

Pré-requisitos e detalhes do ambiente :

- Ficheiros de input na diretoria passada como argumento
- 4.01.0+ocp1-full-mingw64-20160113
- Visual Studio Code 1.33
- OCaml and Reason IDE 1.0.38